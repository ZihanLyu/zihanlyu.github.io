<!DOCTYPE html>
<html>
<body>

<?php
echo "<h2>The information you submitted has now been processed and reported back to you in a new web page</h2>";
?> 

</body>
</html>