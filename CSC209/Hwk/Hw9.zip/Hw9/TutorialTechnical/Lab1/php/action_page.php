<!DOCTYPE html>
<html>
<body>

<?php
echo "<h2>You just clicked Submit. More, later...</h2>";
?> 

</body>
</html>